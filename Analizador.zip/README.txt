Este pequeño proyecto con interfaz gráfica ya implementada requiere un uso con ciertas medidas
que serán explicada a continuación:

1.- El ejecutable recibirá un archivo de texto (.txt) el cual debe tener la sintaxis de un código C

2.- hay ciertas cosas que se deben considerar al escribir el código:

	a) no reconoce saltos de linea sin código

	b) cada palabra escrita, operador y/o palabra reservada debe estar separada por un único espacio entre ellos
	   ejemplo: int a ; 
	   se puede notar que los espacios (representados con _) se encuentran de la sig. forma:
	   int_a_; nótese que previo al inicio de la línea de código no hace falta introducir espacio, 
	   el mismo caso aplica para el final de la linea

	c) no reconoce ni elimina tabuladores (revisar el ejemplo "lexico.txt")

	d) la lista de palabras reservadas se compone de:
		reservadas = ['printf','int','float','char','scanf','main','return','for']
		relacionalesEspeciales = ['==','<=','>=','!=']
		logicos = ['&&','||']
		numerosB = ['1','2','3','4','5','6','7','8','9','0']
		errores = ['@','?','¡','¿','~']
		aritméticosEspeciales = ['++']
		°Observación :aritméticos convencionales ya vienen incluidos de forma nativa

3.- Darle Buen Uso al programa queda a responsabilidad del usuario, los integrantes del equipo ni tienen relación alguna
    con el uso que se le pueda dar

PD:
	Este trabajo fue hecho con cariño por el equipo alfa buena maravilla onda dinamita escuadrón lobo
	mejor conocido como el equipo 1
	Integrantes:
		Austin López Ituarte	  (Austin)
		Kevin García González	  (el que todo lo puede)
		Luis René Morales Velasco (jefe del equipo)
		Uribe Matus Miguel Ángel  (el quejumbroso)
